#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <tclap/CmdLine.h>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/ml/ml.hpp>
#include "common_code.hpp"
#include <opencv2/features2d.hpp>
#include <opencv2/xfeatures2d.hpp>

#define IMG_WIDTH 300

using namespace cv;
using namespace cv::xfeatures2d;
using namespace cv::ml;

int main(int argc, char * argv[])
{
  TCLAP::CmdLine cmd("Clasify a image", ' ', "0.0");

  TCLAP::ValueArg<std::string> basenameArg("b", "basename", "basename for the dataset.", false, "../data", "pathname");
	cmd.add(basenameArg);
  TCLAP::ValueArg<std::string> configFile("c", "config_file", "configuration file for the dataset.", false, "02_ObjectCategories_conf.txt", "pathname");
	cmd.add(configFile);
  TCLAP::ValueArg<std::string> dictionary("d", "dictionary_file", "dictionary file.", false, "dictionary.yml", "pathname");
	cmd.add(dictionary);
	TCLAP::ValueArg<std::string> cl("l", "classifier_file", "classifier file.", false, "classifier.yml", "pathname");
	cmd.add(cl);
  TCLAP::ValueArg<std::string> image("i", "image", "image to clasify", false, "image_0005.jpg", "pathname");
	cmd.add(image);

  TCLAP::ValueArg<int> keywords("w", "keywords", "[KMEANS] Number of keywords generated. Default 100.", false, 100, "int");
  cmd.add(keywords);
  TCLAP::ValueArg<int> ndesc("", "ndesc", "[SIFT] Number of descriptors per image. Value 0 means extract all. Default 0.", false, 0, "int");
  cmd.add(ndesc);
  TCLAP::ValueArg<int> k_nn("", "k_nn", "[KNN] Number k neighbours used to classify. Default 1.", false, 1, "int");
	cmd.add(k_nn);
  TCLAP::ValueArg<int> type("t", "type", "Type of the descriptors (SIFT or SURF). Default 0.", false, 0, "int");
	cmd.add(type);
  TCLAP::ValueArg<int> ntrain("", "ntrain", "Number of samples per class used to train. Default 15.", false, 15, "int");
	cmd.add(ntrain);
  TCLAP::ValueArg<int> ntest("", "ntest", "Number of samples per class used to test. Default 0.", false, 0, "int");
	cmd.add(ntest);

  cmd.parse(argc, argv);

  std::vector<int> samples_per_cat;


  /*----------------------------------------------------------------------------
                              Load the categories
  ----------------------------------------------------------------------------*/

  std::vector<std::string> categories;
  std::string dataset_desc_file = basenameArg.getValue() + "/" + configFile.getValue();

  int retCode;
  if ((retCode = load_dataset_information(dataset_desc_file, categories, samples_per_cat)) != 0)
  {
	std::cerr << "Error: could not load dataset information from '"
		<< dataset_desc_file
		<< "' (" << retCode << ")." << std::endl;
	exit(-1);
  }

  std::cout << "\nFound " << categories.size() << " categories: ";
  for (size_t i=0;i<categories.size();++i)
    std::cout << categories[i] << ' ';
  std::cout << std::endl;

  /*----------------------------------------------------------------------------
                   Load the classifier and the dictionary
  ----------------------------------------------------------------------------*/
 
  Ptr<KNearest> dict = KNearest::load<KNearest>(dictionary.getValue());
  Ptr<KNearest> classifier = KNearest::load<KNearest>(cl.getValue());

  Size size_normal;
  
  Mat test_bovw;
  Mat bovw;

  /*----------------------------------------------------------------------------
                         Evaluate one or more images
  ----------------------------------------------------------------------------*/
  if(ntest.getValue() != 0)
  {
    std::vector<std::vector<int>> train_samples;
    std::vector<std::vector<int>> test_samples;
	std::vector<std::string> images_name;
    create_train_test_datasets(samples_per_cat, ntrain.getValue(), ntest.getValue(), train_samples, test_samples);

	size_normal.width= IMG_WIDTH; 
	/*------------------------------------------------------------------------
	           Extract the descriptor and bovw from the image
	------------------------------------------------------------------------*/
	for (size_t c = 0; c < test_samples.size(); ++c)
    {
        for (size_t s = 0; s < test_samples[c].size(); ++s)
        {
            std::string filename = compute_sample_filename(basenameArg.getValue(), categories[c], test_samples[c][s]);
			images_name.push_back(filename);
            Mat img = imread(filename, IMREAD_GRAYSCALE);
            if (img.empty())
            {
                std::cerr << "Error: could not read image '" << filename << "'." << std::endl;
                exit(-1);
            }
            else
            {
                // Fix size:  width =300px
				size_normal.height=IMG_WIDTH*img.rows/img.cols;
				resize(img, img, size_normal);

				// Extract SIFT descriptors
				//-----------------------------------------------------
				Mat desc;
				if(type.getValue()==0)
					desc = extractSIFTDescriptors(img, ndesc.getValue());
				else
					desc = extractSURFDescriptors(img, ndesc.getValue());

				// Extract bovw from each image
				//-----------------------------------------------------
				bovw = compute_bovw (dict, keywords.getValue(), desc );
				if(test_bovw.empty())
					bovw.copyTo(test_bovw);
				else
					vconcat(test_bovw, bovw, test_bovw);
            }
        }
    }

	/*----------------------------------------------------------------------------
	                         Classify the image
	----------------------------------------------------------------------------*/
	Mat predicted_labels;
	int label;

	label = classifier->findNearest(test_bovw, k_nn.getValue(), predicted_labels);

	for (int i = 0; i < predicted_labels.rows; ++i)
	  std::cout << "\nThe category for the image " << images_name[i] << " is " << categories[(int)predicted_labels.at<float>(i)] << '\n';
  }
  else
  {
	/*----------------------------------------------------------------------------
                              Load the image
	----------------------------------------------------------------------------*/

	Mat img = imread(image.getValue(), IMREAD_GRAYSCALE);
	if (img.empty())
	{
	  std::cerr << "Error: could not read image '" << image.getValue() << "'." << std::endl;
	  exit(-1);
	}
	
	size_normal.width= IMG_WIDTH;
  	size_normal.height = IMG_WIDTH*img.rows/img.cols; 
	resize(img, img, size_normal);

	/*------------------------------------------------------------------------
	           Extract the descriptor and bovw from the image
	------------------------------------------------------------------------*/
	Mat desc;
	if(type.getValue()==0)
	  desc = extractSIFTDescriptors(img, ndesc.getValue());
	else
	  desc = extractSURFDescriptors(img, ndesc.getValue());

	bovw = compute_bovw (dict, keywords.getValue(), desc );
	if(test_bovw.empty())
	  bovw.copyTo(test_bovw);
	else
	  vconcat(test_bovw, bovw, test_bovw);

	/*----------------------------------------------------------------------------
	                         Classify the image
	----------------------------------------------------------------------------*/
	Mat predicted_labels;
	int label;

	label = classifier->findNearest(test_bovw, k_nn.getValue(), predicted_labels);

	std::cout << "\nThe category for the image " << image.getValue() << " is " << categories[label] << '\n';
  }

  std::cout << std::endl;

}
