/*! \file train_bovw.cpp
    \brief Trains a Bag of Visual Words model
    \authors Fundamentos de Sistemas Inteligentes en Vision
*/

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>
#include <tclap/CmdLine.h>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/ml/ml.hpp>
#include "common_code.hpp"
#include <opencv2/features2d.hpp>
#include <opencv2/xfeatures2d.hpp>

#define IMG_WIDTH 300

using namespace cv;
using namespace cv::xfeatures2d;
using namespace cv::ml;

int
main(int argc, char * argv[])
{
	TCLAP::CmdLine cmd("Trains and tests a BoVW model", ' ', "0.0");

	TCLAP::ValueArg<std::string> basenameArg("b", "basename", "basename for the dataset.", false, "../data", "pathname");
	cmd.add(basenameArg);
	TCLAP::ValueArg<std::string> configFile("c", "config_file", "configuration file for the dataset.", false, "02_ObjectCategories_conf.txt", "pathname");
	cmd.add(configFile);
	TCLAP::ValueArg<int> n_runsArg("r", "n_runs", "Number of trials train/test to compute the recognition rate. Default 10.", false, 10, "int");
	cmd.add(n_runsArg);
	TCLAP::ValueArg<int> ndesc("", "ndesc", "[SIFT] Number of descriptors per image. Value 0 means extract all. Default 0.", false, 0, "int");
	cmd.add(ndesc);
	TCLAP::ValueArg<int> keywords("w", "keywords", "[KMEANS] Number of keywords generated. Default 100.", false, 100, "int");
	cmd.add(keywords);
	TCLAP::ValueArg<int> ntrain("", "ntrain", "Number of samples per class used to train. Default 15.", false, 15, "int");
	cmd.add(ntrain);
	TCLAP::ValueArg<int> ntest("", "ntest", "Number of samples per class used to test. Default 50.", false, 50, "int");
	cmd.add(ntest);
	TCLAP::ValueArg<int> k_nn("", "k_nn", "[KNN] Number k neighbours used to classify. Default 1.", false, 1, "int");
	cmd.add(k_nn);

	TCLAP::ValueArg<int> type("t", "type", "Type of the descriptors (SIFT or SURF). Default SIFT.", false, 0, "int");
	cmd.add(type);
	TCLAP::ValueArg<std::string> dictionary("d", "dictionary_file", "dictionary file.", false, "dictionary.yml", "pathname");
	cmd.add(dictionary);
	TCLAP::ValueArg<std::string> cl("l", "classifier_file", "classifier file.", false, "classifier.yml", "pathname");
	cmd.add(cl);


	cmd.parse(argc, argv);

	// --------------- MAIN BLOCK ---------------

	std::vector<std::string> categories;
	std::vector<int> samples_per_cat;

	std::string dataset_desc_file = basenameArg.getValue() + "/" + configFile.getValue();

	int retCode;
	if ((retCode = load_dataset_information(dataset_desc_file, categories, samples_per_cat)) != 0)
	{
		std::cerr << "Error: could not load dataset information from '"
			<< dataset_desc_file
			<< "' (" << retCode << ")." << std::endl;
		exit(-1);
	}

    std::cout << "Found " << categories.size() << " categories: ";
    if (categories.size()<2)
    {
        std::cerr << "Error: at least two categories are needed." << std::endl;
        return -1;
    }

    for (size_t i=0;i<categories.size();++i)
        std::cout << categories[i] << ' ';
    std::cout << std::endl;

		std::vector<float> rRates(n_runsArg.getValue(), 0.0);
		int best_model=0;

    // Repeat training+test
    for (int trial=0; trial<n_runsArg.getValue(); trial++)
    {
        std::clog << "######### TRIAL " << trial+1 << " ##########" << std::endl;

        std::vector<std::vector<int>> train_samples;
        std::vector<std::vector<int>> test_samples;
        create_train_test_datasets(samples_per_cat, ntrain.getValue(), ntest.getValue(), train_samples, test_samples);

		//-----------------------------------------------------
		//                  TRAINING
		//-----------------------------------------------------

        std::clog << "Training ..." << std::endl;
        std::clog << "\tCreating dictionary ... " << std::endl;
        std::clog << "\t\tComputing descriptors..." << std::endl;

        Mat train_descs;
				Mat desc;
				std::vector <Mat> descs_vector;
        std::vector<int> ndescs_per_sample;
				Size size_normal;

				size_normal.width= IMG_WIDTH;
				ndescs_per_sample.resize(0);

        for (size_t c = 0; c < train_samples.size(); ++c)
        {
            std::clog << "  " << std::setfill(' ') << std::setw(3) << (c * 100) / train_samples.size() << " %   \015";
            for (size_t s = 0; s < train_samples[c].size(); ++s)
            {
                std::string filename = compute_sample_filename(basenameArg.getValue(), categories[c], train_samples[c][s]);
                Mat img = imread(filename, IMREAD_GRAYSCALE);
                if (img.empty())
                {
                    std::cerr << "Error: could not read image '" << filename << "'." << std::endl;
                    exit(-1);
                }
                else
                {
                    // Fix size:  width =300px
										size_normal.height=IMG_WIDTH*img.rows/img.cols;
										//size_normal.height = img.rows;
										resize(img, img, size_normal);

										// Extract descriptors
										//-----------------------------------------------------
										if(type.getValue()==0)
                    	desc = extractSIFTDescriptors(img, ndesc.getValue());
										else
											desc = extractSURFDescriptors(img, ndesc.getValue());
										ndescs_per_sample.push_back(c);

										if(train_descs.empty())
											desc.copyTo(train_descs);
										else
											vconcat(train_descs, desc, train_descs);

										descs_vector.push_back(desc);
                }
            }
        }

				// Dictionary computation
				//-----------------------------------------------------
				  Mat keyws;
				  Mat centers;
					std::vector <int> labels;

					double compactness = kmeans(train_descs, keywords.getValue(), keyws, TermCriteria(CV_TERMCRIT_ITER, 10, 0.00001), 3, KMEANS_PP_CENTERS, centers);

					for(int i=0; i<keywords.getValue(); i++)
						labels.push_back(i);

					Ptr<KNearest> dict = KNearest::create();
					dict->train(centers, ROW_SAMPLE, cv::Mat(labels));

        // Compute BoVW for each image
				//-----------------------------------------------------
					Mat bovw;
					Mat bovw_vector;
					bovw_vector.reshape(1, bovw_vector.cols);

		      std::clog << "\tComputing BoVW ... " << std::endl;

		      //For each train image, compute the corresponding bovw.
		      std::clog << "\t\tGenerating a bovw descriptor per training image." << std::endl;

					for(int i=0; i<descs_vector.size(); i++)
					{
						bovw = compute_bovw (dict, keywords.getValue(), descs_vector[i] );

						if(bovw_vector.empty())
							bovw.copyTo(bovw_vector);
						else
							vconcat(bovw_vector, bovw, bovw_vector);
					}

        // Define the classifier type and train it
				//-----------------------------------------------------

					Ptr<KNearest> classifier = KNearest::create();
					classifier->train(bovw_vector, ROW_SAMPLE, cv::Mat(ndescs_per_sample));

		//-----------------------------------------------------
		//                  TESTING
		//-----------------------------------------------------


        std::clog << "Testing .... " << std::endl;

        //load test images, generate SIFT descriptors and quantize getting a bovw for each image.
        //classify and compute errors.
				std::vector<float> true_labels;

        //For each test image, compute the corresponding bovw.
        std::clog << "\tCompute image descriptors for test images..." << std::endl;
        Mat test_bovw;

				for (size_t c = 0; c < test_samples.size(); ++c)
        {
            for (size_t s = 0; s < test_samples[c].size(); ++s)
            {
                std::string filename = compute_sample_filename(basenameArg.getValue(), categories[c], test_samples[c][s]);
                Mat img = imread(filename, IMREAD_GRAYSCALE);
                if (img.empty())
                {
                    std::cerr << "Error: could not read image '" << filename << "'." << std::endl;
                    exit(-1);
                }
                else
                {
                    // Fix size:  width =300px
										size_normal.height=IMG_WIDTH*img.rows/img.cols;
										//size_normal.height = img.rows;
										resize(img, img, size_normal);

										// Extract SIFT descriptors
										//-----------------------------------------------------
										Mat desc;
          					if(type.getValue()==0)
          						desc = extractSIFTDescriptors(img, ndesc.getValue());
										else
											desc = extractSURFDescriptors(img, ndesc.getValue());
										true_labels.push_back(c);

										// Extract bovw from each image
										//-----------------------------------------------------
										bovw = compute_bovw (dict, keywords.getValue(), desc );
										if(test_bovw.empty())
											bovw.copyTo(test_bovw);
										else
											vconcat(test_bovw, bovw, test_bovw);
                }
            }
        }

        std::clog << "\tThere are " << test_bovw.rows << " test images." << std::endl;

        //Classify the test samples.
        std::clog << "\tClassifing test images." << std::endl;
        Mat predicted_labels;

				classifier->findNearest(test_bovw, k_nn.getValue(), predicted_labels);

        //compute the classifier's confusion matrix.
        std::clog << "\tComputing confusion matrix." << std::endl;
        Mat confusion_mat = compute_confusion_matrix(categories.size(), Mat(true_labels), predicted_labels);
        CV_Assert(int(sum(confusion_mat)[0]) == test_bovw.rows);
        double rRate_mean, rRate_dev;
        compute_recognition_rate(confusion_mat, rRate_mean, rRate_dev);
        std::cerr << "Recognition rate mean = " << rRate_mean * 100 << "% dev " << rRate_dev * 100 << std::endl;
        rRates[trial]=rRate_mean;

				//Saving the best models: dictionary and classifier, format YML
				if( (rRates[trial] >= rRates[best_model]) or trial == 0)
				{
					best_model = trial;

					dict->save(dictionary.getValue());
					classifier->save(cl.getValue());
				}

    }

    std::clog << "###################### FINAL STATISTICS  ################################" << std::endl;

    double rRate_mean = 0.0;
    double rRate_dev = 0.0;
		std::cout << "best model: " << rRates[best_model] << " " << best_model << '\n';
		for(int i=0; i<rRates.size(); i++)
		{
			rRate_mean += rRates[i];
		}
		rRate_mean /= n_runsArg.getValue();

		for(int i=0; i<rRates.size(); i++)
		{
			rRate_dev += pow(rRates[i] - rRate_mean, 2);
		}
		rRate_dev = sqrt(rRate_dev / n_runsArg.getValue());

    std::clog << "Recognition Rate mean " << rRate_mean*100.0 << "% dev " << rRate_dev*100.0 << std::endl;
    return 0;
}
