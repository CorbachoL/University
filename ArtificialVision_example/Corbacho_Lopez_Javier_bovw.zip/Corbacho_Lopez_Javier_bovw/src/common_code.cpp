/*! \file     common_code.cpp
    \brief    Code for image categorization functions
	\authors  Fundamentos de sistemas inteligentes en vision
	\date     2017
*/

#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "common_code.hpp"
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <opencv2/core/core.hpp>
#include "opencv2/highgui/highgui.hpp"
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>

using namespace cv;
using namespace cv::xfeatures2d;

void basename(const std::string& path,
                     std::string& dirname,
                     std::string& filename,
                     std::string& ext)
{
    dirname="";
    filename=path;
    ext="";

    auto pos = path.rfind("/");

    if (pos != std::string::npos)
    {
      dirname=path.substr(0, pos);
      filename=path.substr(pos+1);
    }

    pos = filename.rfind(".");

    if (pos != std::string::npos)
    {
      ext = filename.substr(pos+1);
      filename = filename.substr(0,pos);
    }
    return;
}

std::string compute_sample_filename(const std::string& basename, const std::string& cat, const int sample_index)
{
    std::ostringstream filename;
    filename << basename << "/101_ObjectCategories/" << cat << "/image_" << std::setfill('0') << std::setw(4) << sample_index << ".jpg";
    return filename.str();
}

int load_dataset_information(const std::string& fname, std::vector<std::string>& categories, std::vector<int>& samples_per_cat)
{
   int retCode = 0;
   std::ifstream in (fname);

   if (!in)
       retCode = 1;
   else
   {
       while((in) && (retCode==0) )
       {
           std::string catName;
           int nsamples;
           in >> catName >> nsamples;
           if (!in)
           {
               if (! in.eof())
                retCode = 2;
           }
           else
           {
               categories.push_back(catName);
               samples_per_cat.push_back(nsamples);
           }
       }
   }
   return retCode;
}

void random_sampling (int total, int ntrain, int ntest,
                      std::vector< int >& train_samples,
                      std::vector< int >& test_samples)
{
    assert(ntrain<total);
    train_samples.resize(0);
    test_samples.resize(0);
    std::vector<bool> sampled(total, false);
    while (ntrain>0)
    {
        int s = int(double(total) * rand()/(RAND_MAX+1.0));
        int i=0;
        while(sampled[i] && i<sampled.size()) ++i; //the first unsampled.
        int c=0;
        while (c<s) //count s unsampled.
        {
            while (sampled[++i]); //advance to next unsampled.
            ++c;
        }
        assert(!sampled[i]);
        train_samples.push_back(i+1);
        sampled[i]=true;
        --total;
        --ntrain;
    }
    if (ntest>=total)
    {
        for (size_t i=0 ; i<sampled.size(); ++i)
            if (!sampled[i])
                test_samples.push_back(i+1);
    }
    else
    {
        while (ntest>0)
        {
            int s = int(double(total) * rand()/(RAND_MAX+1.0));
            int i=0;
            while(sampled[i] && i<sampled.size()) ++i; //the first unsampled.
            int c=0;
            while (c<s) //count s unsampled.
            {
                while (sampled[++i]); //advance to next unsampled.
                ++c;
            }
            test_samples.push_back(i+1);
            sampled[i]=true;
            --total;
            --ntest;
        }
    }
}

void create_train_test_datasets (std::vector<int>& samples_per_cat, int ntrain_samples, int ntest_samples,
                                 std::vector< std::vector <int> >& train_samples, std::vector< std::vector<int> >& test_samples)
{
    train_samples.resize(0);
    test_samples.resize(0);
    for (size_t i=0;i<samples_per_cat.size(); ++i)
    {
        std::vector<int> train;
        std::vector<int> test;
        random_sampling (samples_per_cat[i], ntrain_samples, ntest_samples, train, test);
        train_samples.push_back(train);
        test_samples.push_back(test);
    }
}

Mat compute_confusion_matrix(int n_categories, const Mat& true_labels, const Mat& predicted_labels)
{
    CV_Assert(true_labels.rows == predicted_labels.rows);
    CV_Assert(true_labels.type()==CV_32FC1);
    //CV_Assert(predicted_labels.type()==CV_32FC1);
    Mat confussion_mat = Mat::zeros(n_categories, n_categories, CV_32F);
    for (int i = 0; i < true_labels.rows; ++i)
    {
        confussion_mat.at<float>(true_labels.at<float>(i), predicted_labels.at<float>(i)) += 1.0;
    }
    return confussion_mat;
}

void compute_recognition_rate(const Mat& cmat, double& mean, double& dev)
{
    CV_Assert(cmat.rows == cmat.cols && cmat.rows>1);
    CV_Assert(cmat.depth()==CV_32F);

    mean = 0.0;
    dev = 0.0;
    for (int c=0; c<cmat.rows; ++c)
    {
        const double class_Rate = cmat.at<float>(c,c)/sum(cmat.row(c))[0];
        mean += class_Rate;
        dev += class_Rate*class_Rate;
    }
    mean /= double(cmat.rows);
    dev = sqrt(dev/double(cmat.rows) - mean*mean);
}

Mat extractSIFTDescriptors(const Mat& img, const int ndesc)
{
  Mat descs;

  Ptr<SIFT> detector = SIFT::create();
  std::vector<KeyPoint> keypoints;

  if( !img.data )
  {
    std::cout<< " --(!) Error reading images " << std::endl;
    exit(-1);
  }

  detector->detectAndCompute( img, Mat(), keypoints, descs );

  return descs;
}

Mat extractSURFDescriptors(const Mat& img, const int ndesc)
{
  Mat descs;

  Ptr<SURF> detector = SURF::create();
  std::vector<KeyPoint> keypoints;

  if( !img.data )
  {
    std::cout<< " --(!) Error reading images " << std::endl;
    exit(-1);
  }

  detector->detectAndCompute( img, Mat(), keypoints, descs );

  return descs;
}

Mat
compute_bovw (const Ptr<ml::KNearest>& dict, const int dict_size, Mat& img_descs, bool normalize)
{
    Mat bovw = cv::Mat::zeros(1, dict_size, CV_32F);
    Mat result;

    dict->findNearest(img_descs, 1, result);

    for(int x=0; x<result.rows; x++)
		{
			bovw.at<float>( (int)result.at<float>(x) )++;
		}

    if(normalize==true)
      cv::normalize(bovw, bovw, 1, 0, NORM_MINMAX);
      //bovw/=img_descs.rows;

    return bovw;
}
