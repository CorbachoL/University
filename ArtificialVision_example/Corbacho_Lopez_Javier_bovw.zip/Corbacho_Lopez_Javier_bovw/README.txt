
1. Create a directory (for example "build")
2. Open a terminal and execute "cmake ../CMake_files/"
3. Execute "make"
4. Run the program

